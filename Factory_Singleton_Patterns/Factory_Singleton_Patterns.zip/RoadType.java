package Factory_Singleton_Patterns;

public enum RoadType {
    CITY,
    OFF_ROAD,
    GROSS;
}
